<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\Mstrtindakan $model */

$this->title = 'Create Mstrtindakan';
$this->params['breadcrumbs'][] = ['label' => 'Mstrtindakans', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="mstrtindakan-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
