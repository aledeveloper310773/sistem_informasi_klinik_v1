<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\Mstrtindakan $model */

$this->title = 'Update Mstrtindakan: ' . $model->id_tindakan;
$this->params['breadcrumbs'][] = ['label' => 'Mstrtindakans', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_tindakan, 'url' => ['view', 'id_tindakan' => $model->id_tindakan]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="mstrtindakan-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
