<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\Mstrwilayah $model */

$this->title = 'Create Mstrwilayah';
$this->params['breadcrumbs'][] = ['label' => 'Mstrwilayahs', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="mstrwilayah-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
