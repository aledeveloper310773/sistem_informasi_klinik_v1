-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2024 at 04:04 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_klinik`
--

-- --------------------------------------------------------

--
-- Table structure for table `mstrobat`
--

CREATE TABLE `mstrobat` (
  `id_obat` int(11) NOT NULL,
  `nama_obat` varchar(50) NOT NULL,
  `hrg_obat` decimal(18,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mstrobat`
--

INSERT INTO `mstrobat` (`id_obat`, `nama_obat`, `hrg_obat`) VALUES
(1, 'Panadol', '8000'),
(2, 'Sanagrip', '5000');

-- --------------------------------------------------------

--
-- Table structure for table `mstrpegawai`
--

CREATE TABLE `mstrpegawai` (
  `id_pegawai` int(11) NOT NULL,
  `nama_pegawai` varchar(50) NOT NULL,
  `alamat_pegawai` varchar(100) NOT NULL,
  `telp_pegawai` varchar(15) NOT NULL,
  `email_pegawai` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mstrpegawai`
--

INSERT INTO `mstrpegawai` (`id_pegawai`, `nama_pegawai`, `alamat_pegawai`, `telp_pegawai`, `email_pegawai`) VALUES
(1, 'Leo', 'ciwastra', '082295034264', 'aledeveloper310773@gmail.com'),
(2, 'Gugun gunadi', 'Banjaran', '08343434', 'gugun@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `mstrtindakan`
--

CREATE TABLE `mstrtindakan` (
  `id_tindakan` int(11) NOT NULL,
  `nama_tindakan` varchar(50) NOT NULL,
  `hrg_tindakan` decimal(18,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mstrtindakan`
--

INSERT INTO `mstrtindakan` (`id_tindakan`, `nama_tindakan`, `hrg_tindakan`) VALUES
(1, 'Operasi kecil', '500000'),
(2, 'Operasi Besar', '1000000');

-- --------------------------------------------------------

--
-- Table structure for table `mstruser`
--

CREATE TABLE `mstruser` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(50) NOT NULL,
  `id_pegawai` int(11) NOT NULL,
  `password_user` varchar(15) NOT NULL,
  `level_user` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mstruser`
--

INSERT INTO `mstruser` (`id_user`, `nama_user`, `id_pegawai`, `password_user`, `level_user`) VALUES
(1, 'ale', 1, '123', 'admin'),
(2, 'gugun', 2, '456', 'staff');

-- --------------------------------------------------------

--
-- Table structure for table `mstrwilayah`
--

CREATE TABLE `mstrwilayah` (
  `id_wilayah` int(11) NOT NULL,
  `nama_wilayah` varchar(50) NOT NULL,
  `keterangan_wilayah` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mstrwilayah`
--

INSERT INTO `mstrwilayah` (`id_wilayah`, `nama_wilayah`, `keterangan_wilayah`) VALUES
(1, 'Kota', 'Wilayah kota'),
(2, 'Kabupaten', 'Wilayah kabupaten');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mstrobat`
--
ALTER TABLE `mstrobat`
  ADD PRIMARY KEY (`id_obat`);

--
-- Indexes for table `mstrpegawai`
--
ALTER TABLE `mstrpegawai`
  ADD PRIMARY KEY (`id_pegawai`);

--
-- Indexes for table `mstrtindakan`
--
ALTER TABLE `mstrtindakan`
  ADD PRIMARY KEY (`id_tindakan`);

--
-- Indexes for table `mstruser`
--
ALTER TABLE `mstruser`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `mstrwilayah`
--
ALTER TABLE `mstrwilayah`
  ADD PRIMARY KEY (`id_wilayah`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mstrobat`
--
ALTER TABLE `mstrobat`
  MODIFY `id_obat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `mstrpegawai`
--
ALTER TABLE `mstrpegawai`
  MODIFY `id_pegawai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `mstrtindakan`
--
ALTER TABLE `mstrtindakan`
  MODIFY `id_tindakan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `mstruser`
--
ALTER TABLE `mstruser`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `mstrwilayah`
--
ALTER TABLE `mstrwilayah`
  MODIFY `id_wilayah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
