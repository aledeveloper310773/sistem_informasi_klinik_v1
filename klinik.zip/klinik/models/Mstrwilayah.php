<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "mstrwilayah".
 *
 * @property int $id_wilayah
 * @property string $nama_wilayah
 * @property string $keterangan_wilayah
 */
class Mstrwilayah extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'mstrwilayah';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama_wilayah', 'keterangan_wilayah'], 'required'],
            [['nama_wilayah'], 'string', 'max' => 50],
            [['keterangan_wilayah'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_wilayah' => 'Id Wilayah',
            'nama_wilayah' => 'Nama Wilayah',
            'keterangan_wilayah' => 'Keterangan Wilayah',
        ];
    }
}
