<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "mstruser".
 *
 * @property int $id_user
 * @property string $nama_user
 * @property int $id_pegawai
 * @property string $password_user
 * @property string $level_user
 */
class Mstruser extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'mstruser';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama_user', 'id_pegawai', 'password_user', 'level_user'], 'required'],
            [['id_pegawai'], 'integer'],
            [['nama_user'], 'string', 'max' => 50],
            [['password_user', 'level_user'], 'string', 'max' => 15],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_user' => 'Id User',
            'nama_user' => 'Nama User',
            'id_pegawai' => 'Id Pegawai',
            'password_user' => 'Password User',
            'level_user' => 'Level User',
        ];
    }
}
