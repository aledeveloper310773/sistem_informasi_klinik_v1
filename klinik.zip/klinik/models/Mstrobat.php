<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "mstrobat".
 *
 * @property int $id_obat
 * @property string $nama_obat
 * @property float $hrg_obat
 */
class Mstrobat extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'mstrobat';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama_obat', 'hrg_obat'], 'required'],
            [['hrg_obat'], 'number'],
            [['nama_obat'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_obat' => 'Id Obat',
            'nama_obat' => 'Nama Obat',
            'hrg_obat' => 'Hrg Obat',
        ];
    }
}
