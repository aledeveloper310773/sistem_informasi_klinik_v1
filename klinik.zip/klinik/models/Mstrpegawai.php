<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "mstrpegawai".
 *
 * @property int $id_pegawai
 * @property string $nama_pegawai
 * @property string $alamat_pegawai
 * @property string $telp_pegawai
 * @property string $email_pegawai
 */
class Mstrpegawai extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'mstrpegawai';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama_pegawai', 'alamat_pegawai', 'telp_pegawai', 'email_pegawai'], 'required'],
            [['nama_pegawai', 'email_pegawai'], 'string', 'max' => 50],
            [['alamat_pegawai'], 'string', 'max' => 100],
            [['telp_pegawai'], 'string', 'max' => 15],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_pegawai' => 'Id Pegawai',
            'nama_pegawai' => 'Nama Pegawai',
            'alamat_pegawai' => 'Alamat Pegawai',
            'telp_pegawai' => 'Telp Pegawai',
            'email_pegawai' => 'Email Pegawai',
        ];
    }
}
